#!/usr/bin/env python
# coding: utf-8

# Copyright (c) Chung Chan.
# Distributed under the terms of the Modified BSD License.

"""
Information about the frontend package of the widgets.
"""

module_name = "jupyter-optmwidgets"
module_version = "^0.1.5"
