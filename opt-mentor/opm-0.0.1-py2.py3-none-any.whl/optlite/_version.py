#!/usr/bin/env python
# coding: utf-8

# Copyright (c) Chung Chan.
# Distributed under the terms of the Modified BSD License.

version_info = (0, 0, 4)
__version__ = ".".join(map(str, version_info))