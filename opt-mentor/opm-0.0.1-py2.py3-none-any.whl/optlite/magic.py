from IPython.core.magic import Magics, magics_class, line_cell_magic
from .visualizer import visualize

@magics_class
class MentorMagic(Magics):
    @line_cell_magic
    def mentor(self, line, cell=None):
        """Magic command for OPTLite visualization.
        Usage: %%mentor [options] code
        """
        code = cell if cell is not None else line
        return visualize(code)

def load_ipython_extension(ipython):
    """Load the extension in IPython."""
    ipython.register_magics(MentorMagic)
